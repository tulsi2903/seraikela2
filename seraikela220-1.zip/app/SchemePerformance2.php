<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemePerformance2 extends Model
{
    //
    protected $table = "scheme_performance_2";
    protected $primaryKey = "scheme_performance_id";
}
