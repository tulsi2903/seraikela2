<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PMAYGPerformance extends Model
{
    protected $table = "pmayg_performance";
    protected $primaryKey = "pmayg_performance_id";
}
