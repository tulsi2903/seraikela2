<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MgnregaCategory extends Model
{
    protected $table="mgnrega_category";
    protected $primaryKey="mgnrega_category_id";
}
