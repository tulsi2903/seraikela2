<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PMAYGTarget extends Model
{
    protected $table = "pmayg_target";
    protected $primaryKey  = "pmayg_target_id";
}
