<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetGallery extends Model
{
    //
    protected $table = "asset_gallery";
    protected $primaryKey = "asset_gallery_id";
}
