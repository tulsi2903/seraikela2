<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetNumbers extends Model
{
    public $table = "asset_numbers";
    protected $primaryKey = 'asset_numbers_id';
}
