<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fav_Block extends Model
{
    public $table = "favourite_block";
    protected $primaryKey = 'favourite_block_id';
}
