<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class scheme_block_performance extends Model
{
    protected $table = "scheme_block_performance";
    protected $primaryKey  = "scheme_block_performance_id";
}
