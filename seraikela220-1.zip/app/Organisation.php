<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Organisation extends Model
{
    //
    protected $table = "organisation";
    protected $primarykey  = "org_id";
}
