<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeType extends Model
{
    protected $table = 'scheme_type';
    protected $primaryKey = 'sch_type_id';
}
