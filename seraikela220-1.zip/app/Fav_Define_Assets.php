<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fav_Define_Assets extends Model
{
    public $table = "favourite_define_assets";
    protected $primaryKey = 'favourite_asset_id';
}
