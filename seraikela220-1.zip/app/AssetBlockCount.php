<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetBlockCount extends Model
{
    protected $table = 'asset_block_count';
    protected $primaryKey = 'asset_block_count_id';
}
