<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class asset_cat extends Model
{
    protected $table = 'asset_cat';
    protected $primaryKey = 'asset_cat_id';
}
