<?php $__env->startSection('title', 'Favourites'); ?>

<?php $__env->startSection('page-style'); ?>
    <style>
        
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-content'); ?>

<!-------------------------------------------------starting of body---------------------------------------------------->
        <div class="card">
            <div class="col-md-12">
                    <div class="card-header">
                        <div class="card-head-row card-tools-still-right" style="background:#fff;">
                            <h4 class="card-title"><?php echo e($phrase->add_favourites_details); ?></h4>
                            <div class="card-tools">
                               
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-2">
                                <div class="nav flex-column nav-pills nav-secondary nav-pills-no-bd" id="v-pills-tab-without-border" role="tablist" aria-orientation="vertical">
                                    <a class="nav-link active" id="v-pills-home-tab-nobd" data-toggle="pill" href="#v-pills-home-nobd" role="tab" aria-controls="v-pills-home-nobd" aria-selected="true"><?php echo e($phrase->department); ?></a>
                                    <a class="nav-link" id="v-pills-profile-tab-nobd" data-toggle="pill" href="#v-pills-profile-nobd" role="tab" aria-controls="v-pills-profile-nobd" aria-selected="false"><?php echo e($phrase->scheme); ?></a>
                                    <a class="nav-link" id="v-pills-messages-tab-nobd" data-toggle="pill" href="#v-pills-messages-nobd" role="tab" aria-controls="v-pills-messages-nobd" aria-selected="false"><?php echo e($phrase->block); ?></a>
                                    <a class="nav-link" id="v-pills-report-tab-nobd" data-toggle="pill" href="#v-pills-report-nobd" role="tab" aria-controls="v-pills-report-nobd" aria-selected="false"><?php echo e($phrase->panchayat); ?></a>
                                    <a class="nav-link" id="v-pills-asset-tab-nobd" data-toggle="pill" href="#v-pills-asset-nobd" role="tab" aria-controls="v-pills-asset-nobd" aria-selected="false"><?php echo e($phrase->resource); ?></a>
                                </div>
                            </div>
                        
                            <div class="col-md-10" id="printable-area">
                                <div class="tab-content" id="v-pills-without-border-tabContent">
                                    <div class="tab-pane fade show active" id="v-pills-home-nobd" role="tabpanel" aria-labelledby="v-pills-home-tab-nobd">
                                        <div style="float: right;">
                                            <a href="<?php echo e(url('fav_department/pdf/pdfURL')); ?>" target="_blank" data-toggle="tooltip" title="<?php echo e($phrase->export_pdf); ?>"><button type="button" class="btn btn-icon btn-round btn-warning" ><i class="fas fa-file-export"></i></button></a>
                                            <a href="<?php echo e(url('fav_department/export/excelURL')); ?>" data-toggle="tooltip" title="<?php echo e($phrase->export_excel); ?>"><button type="button" class="btn btn-icon btn-round btn-primary" ><i class="fas fa-file-excel"></i></button></a>
                                        </div><br><br>
                                            <form action="<?php echo e(url('fav_department')); ?>" method="post" >
                                                    <?php echo csrf_field(); ?>
                                      
                                            <div class="table-responsive">
                                                <table class="display  table table-striped table-hover" >
                                                    <thead style="background: #d6dcff;color: #000;">
                                                        <tr>
                                                            <th>#</th>
                                                            <th><?php echo e($phrase->department_name); ?> </th>
                                                                                                   
                                                        </tr>
                                                    </thead>
                                                    <tbody>                                                                    
                                                    <?php if(count($datas_dept)!=0): ?>
                                                        <?php $__currentLoopData = $datas_dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <!-- <?php if($val->is_active=='1'): ?> -->
                                                                <tr>
                                                                    <td><input type="checkbox" name="dept_id[]" value="<?php echo e($val->dept_id); ?>" <?php if($val->checked==1): ?> checked <?php endif; ?>> </td>
                                                                    <td><?php echo e($val->dept_name); ?></d>
                                                                    
                                                                </tr>
                                                            <!-- <?php endif; ?> -->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    </tbody>
                                                </table> 
                                            </div>
                                           
                                      
                                        <hr class="new2" style="width: 98%;"> 
                                        <div class="card-action" style="margin-top: -29px;">   
                                                <button type="submit" class="btn btn-secondary"><?php echo e($phrase->submit); ?></button>
                                            </div>
                                        </form>
                                    </div><!--END OF TAB-->


                                    <div class="tab-pane fade" id="v-pills-profile-nobd" role="tabpanel" aria-labelledby="v-pills-profile-tab-nobd">
                                        <div style="float: right;margin-right: 2em;margin-bottom: 1em;">
                                            <a href="<?php echo e(url('fav_scheme/pdf/pdfURL')); ?>" target="_blank" data-toggle="tooltip" title="<?php echo e($phrase->export_pdf); ?>"><button type="button" class="btn btn-icon btn-round btn-warning" ><i class="fas fa-file-export"></i></button></a>
                                            <a href="<?php echo e(url('fav_scheme/export/excelURL')); ?>" data-toggle="tooltip" title="<?php echo e($phrase->export_excel); ?>"><button type="button" class="btn btn-icon btn-round btn-primary" ><i class="fas fa-file-excel"></i></button></a>
                                        </div><br><br>
                                            <form action="<?php echo e(url('fav_scheme')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                        <div class="card-body" style="margin-top:-32px;">											
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead style="background: #d6dcff;color: #000;">
                                                        <tr>
                                                            <th>#</th>
                                                            <th><?php echo e($phrase->scheme_name); ?></th>
                                                            <th><?php echo e($phrase->short_name); ?></th>
                                                                 
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if(count($datas_scheme)!=0): ?>
                                                            <?php $__currentLoopData = $datas_scheme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><input type="checkbox" name="scheme_id[]" value="<?php echo e($val->scheme_id); ?>" <?php if($val->checked==1): ?> checked <?php endif; ?>></td>
                                                                    <td><?php echo e($val->scheme_name); ?></td>
                                                                    <td><?php echo e($val->scheme_short_name); ?></td>
                                                                    <!-- <td><?php echo e($val->scheme_id); ?></td> -->
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div><!--end of card body-->
                                        <hr class="new2" style="width: 98%;"> 
                                        <div class="card-action" style="margin-top: -29px;">   
                                                <button type="submit" class="btn btn-secondary"><?php echo e($phrase->submit); ?></button>
                                            </div>
                                            </form>
                                    </div>  <!-- end of tab -->
                                    
                                    <div class="tab-pane fade" id="v-pills-messages-nobd" role="tabpanel" aria-labelledby="v-pills-messages-tab-nobd">
                                        <div style="float: right;margin-right: 2em;margin-bottom: 1em;">
                                            <a href="<?php echo e(url('fav_block/pdf/pdfURL')); ?>" target="_blank" data-toggle="tooltip" title="<?php echo e($phrase->export_pdf); ?>"><button type="button" class="btn btn-icon btn-round btn-warning" ><i class="fas fa-file-export"></i></button></a>
                                            <a href="<?php echo e(url('fav_block/export/excelURL')); ?>" data-toggle="tooltip" title="<?php echo e($phrase->export_excel); ?>"><button type="button" class="btn btn-icon btn-round btn-primary" ><i class="fas fa-file-excel"></i></button></a>
                                        </div><br><br>
                                            <form action="<?php echo e(url('fav_block')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                        <div class="card-body" style="margin-top:-32px;">											
                                            <div class="table-responsive">
                                                    <table class="table table-datatable" id="printable-area">
                                                            <thead style="background: #d6dcff;color: #000;">
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th><?php echo e($phrase->name_of_block); ?></th>
                                                                    <!-- <th>Name of Block</th> -->
                                                                </tr>
                                                            </thead>
                                                           
                                                            <?php if(count($datas_block)!=0): ?>
                                                                <?php $__currentLoopData = $datas_block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><input type="checkbox" name="block_id[]" value=<?php echo e($val->geo_id); ?> <?php if($val->checked==1): ?> checked <?php endif; ?>></td>
                                                                        <td><?php echo e($val->geo_name); ?></td>
                                                                        <!-- <td><?php echo e($val->geo_id); ?></td> -->
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </table>
                                            </div>
                                        </div><!--end of card body-->
                                        <hr class="new2" style="width: 98%;"> 
                                        <div class="card-action" style="margin-top: -29px;">   
                                                <button class="btn btn-secondary"><?php echo e($phrase->submit); ?></button>
                                            </div>
                                            </form>
                                    </div>
                                    
                                                                       
                                    <div class="tab-pane fade" id="v-pills-report-nobd" role="tabpanel" aria-labelledby="v-pills-report-tab-nobd" style="overflow-y: scroll; height:600px;">
                                        <div style="float: right;margin-right: 2em;margin-bottom: 1em;">
                                            <a href="<?php echo e(url('fav_panchayat/pdf/pdfURL')); ?>" target="_blank" data-toggle="tooltip" title="<?php echo e($phrase->export_pdf); ?>"><button type="button" class="btn btn-icon btn-round btn-warning" ><i class="fas fa-file-export"></i></button></a>
                                            <a href="<?php echo e(url('fav_panchayat/export/excelURL')); ?>" data-toggle="tooltip" title="<?php echo e($phrase->export_excel); ?>"><button type="button" class="btn btn-icon btn-round btn-primary" ><i class="fas fa-file-excel"></i></button></a>
                                        </div><br><br>
                                            <form action="<?php echo e(url('fav_panchayat')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                        <div class="card-body" style="margin-top:-32px;">																								
                                            <div class="table-responsive">
                                                <table class="display table-datatable table table-striped table-hover">
                                                    <thead style="background: #d6dcff;color: #000;">
                                                        <tr>
                                                            <th colspan="5"><?php echo e($phrase->name_of_panchayat); ?></th>
                                                        </tr>
                                                    </thead>
                                                
                                                    <tbody>
                                                        <?php if(count($datas_panchayat)!=0): ?>
                                                        <tr>
                                                            <?php $__currentLoopData = $datas_panchayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><input type="checkbox" name="panchayat_id[]"  value=<?php echo e($val->geo_id); ?> <?php if($val->checked==1): ?> checked <?php endif; ?>> <?php echo e($datas_panchayat[$key]['geo_name']); ?></td>
                                                            <?php 
                                                                if((($key+1) % 5) == 0){
                                                                    echo "</tr><tr>";
                                                                }
                                                            ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div><!--end of card body-->
                                        <hr class="new2" style="width: 98%;"> 
                                        <div class="card-action" style="margin-top: -29px;">   
                                                <button class="btn btn-secondary"><?php echo e($phrase->submit); ?></button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="tab-pane fade" id="v-pills-asset-nobd" role="tabpanel" aria-labelledby="v-pills-asset-tab-nobd" style="overflow-y: scroll; height:600px;">
                                        <div style="float: right;margin-right: 2em;margin-bottom: 1em;">
                                            <a href="<?php echo e(url('fav_define_asset/pdf/pdfURL')); ?>" target="_blank" data-toggle="tooltip" title="<?php echo e($phrase->export_pdf); ?>"><button type="button" class="btn btn-icon btn-round btn-warning" ><i class="fas fa-file-export"></i></button></a>
                                            <a href="<?php echo e(url('fav_define_asset/export/excelURL')); ?>" data-toggle="tooltip" title="<?php echo e($phrase->export_excel); ?>"><button type="button" class="btn btn-icon btn-round btn-primary" ><i class="fas fa-file-excel"></i></button></a>
                                        </div><br><br>
                                            <form action="<?php echo e(url('fav_define_asset')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                        <div class="card-body" style="margin-top:-32px;">																								
                                            <div class="table-responsive">
                                                <table class="display table-datatable table table-striped table-hover">
                                                    <thead style="background: #d6dcff;color: #000;">
                                                        <tr>
                                                            <th>#</th>
                                                            <th><?php echo e($phrase->assets_name); ?></th>
                                                            <th><?php echo e($phrase->department_name); ?></th>
                                                        </tr>
                                                    </thead>
                                                
                                                    <tbody>
                                                        <?php if(count($datas_define_asset)!=0): ?>
                                                            <?php $__currentLoopData = $datas_define_asset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><input type="checkbox" name="asset_id[]" value="<?php echo e($val->asset_id); ?>" <?php if($val->checked==1): ?> checked <?php endif; ?>></td> 
                                                                    <td><?php echo e($val->asset_name); ?></td>
                                                                    <td><?php echo e($val->dept_name); ?></td>
                                                                   
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div><!--end of card body-->
                                        <hr class="new2" style="width: 98%;"> 
                                        <div class="card-action" style="margin-top: -29px;">   
                                                <button class="btn btn-secondary"><?php echo e($phrase->submit); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </form>  
                            </div>                       
                        </div>
                    </div>
             
          
</div><!--end of content-->
</div>

<?php $__env->stopSection(); ?>

  

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seraikela2\resources\views/favourite/fav_all.blade.php ENDPATH**/ ?>