<style>
@media  screen and (min-width: 991px){
.static-sidebar .footer {
    position: fixed important;
    bottom: 0;
    left: 0;
    z-index: +555;
    width: 100vw;
}
.footer {
    position: fixed;
    padding: 5px;
    position: absolute;
    width: 100%;
    margin-top: 31px;
    background: #000;
}
}
</style>
<footer class="footer">
<h6 style="text-align: center; color: #fff;">  DC SERAIKELA © 2019 IT-SCIENT</h6>
</footer><?php /**PATH C:\xampp\htdocs\seraikela2\resources\views/layout/footer.blade.php ENDPATH**/ ?>