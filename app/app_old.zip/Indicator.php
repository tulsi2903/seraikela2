<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeIndicator extends Model
{
    protected $table = "scheme_indicator";
    protected $primaryKey = "indicator_id";
}
