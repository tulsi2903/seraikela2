<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeGeoTarget extends Model
{
     protected $table = "scheme_geo_target";
    protected $primaryKey = "scheme_geo_target_id";
}
