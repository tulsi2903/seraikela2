<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MgnregaPerformance extends Model
{
    //
    protected $table = "mgnrega_performance";
    protected $primaryKey = "mgnrega_performance_id";
}
