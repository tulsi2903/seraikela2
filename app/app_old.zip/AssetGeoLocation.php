<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetGeoLocation extends Model
{
    protected $table = 'asset_geo_location';
    protected $primaryKey = 'asset_geo_loc_id';
}
