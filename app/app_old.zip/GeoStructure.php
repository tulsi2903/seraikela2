<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GeoStructure extends Model
{
    //
    protected $table = "geo_structure";
    protected $primaryKey = "geo_id";
}
