<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeAsset extends Model
{
    protected $table = 'scheme_assets';
    protected $primaryKey = 'scheme_asset_id';
}
 