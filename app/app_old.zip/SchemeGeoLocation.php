<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeGeoLocation extends Model
{
    //
    protected $table = "scheme_geo_location";
    protected $primaryKey = "scheme_geo_location_id";
}
