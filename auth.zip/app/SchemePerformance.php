<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemePerformance extends Model
{
     public $table = "scheme_performance";
    protected $primaryKey = 'scheme_performance_id ';
}
