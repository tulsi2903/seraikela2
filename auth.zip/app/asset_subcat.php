<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class asset_subcat extends Model
{
    protected $table = 'asset_subcat';
    protected $primaryKey = 'asset_sub_id';
}
