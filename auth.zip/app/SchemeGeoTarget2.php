<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeGeoTarget2 extends Model
{
    //
    protected $table = "scheme_geo_target_2";
    protected $primaryKey = "scheme_geo_target_id";
}
