<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fav_Dept extends Model
{
    public $table = "favourite_department";
    protected $primaryKey = 'favourite_department_id';
}
