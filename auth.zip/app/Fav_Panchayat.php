<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fav_Panchayat extends Model
{
    public $table = "favourite_panchayat";
    protected $primaryKey = 'favourite_panchayat_id';
}
