<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchemeStructure extends Model
{
    //
    protected $table = "scheme_structure";
    protected $primaryKey = "scheme_id";
}
