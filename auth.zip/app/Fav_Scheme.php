<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fav_Scheme extends Model
{
    public $table = "favourite_scheme";
    protected $primaryKey = 'favourite_scheme_id';
    
}
