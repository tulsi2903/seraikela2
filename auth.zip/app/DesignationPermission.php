<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DesignationPermission extends Model
{
    public $table = "desig_permission";
    protected $primaryKey = 'desig_permission_id';
}
