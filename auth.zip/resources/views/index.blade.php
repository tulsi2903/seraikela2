@extends('layout.layout')

@section('title', 'Seraikela')

@section('page-content')
    <div class="row row-card-no-pd" style="border-top: 3px solid #5c76b7;">
        <div class="col-md-12">
            <h1>Dashboard</h1>
        </div>
    </div>
@endsection